# mpc

This repo contains the files associated with the django polling tutorial that can be found at https://www.djangoproject.com/.  I decided to name this project, MyPollingCompany, hence the name "mpc."

Notes:

(1) Files may contain multiple versions of content.  I did this so I could keep track of what changed throughout the tutorial.

(2) I used the python-decouple module to separate sensitive parameters from the settings.py file.  See the "dotenv" file for the parameter names that would be stored in thje ".env" file./

(3) I built this on Amazon Linux 2 and python 3.6.

(4) My LAMP stack consists of Apache, php7.2, and mariadb.

(5) Check the requirements.txt file for python modules.

(6) Check yum.sh for the yum packages and Amazon Linux 2 extras that you need.

(7) Create your own background file in "mpc/polls/static/polls/images".

(8) I decoupled sensitive stuff using python-decouple. The file "dotenv" shows what values need to be in the ".env" file.
